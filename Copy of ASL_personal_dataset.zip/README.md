# ASL personal hand-sign image dataset

* **Images:** 1,300  (letters: 26/26)
* **Sessions:** s01
* **Recorded:** 2026-11-18T10:59:37 to 2026-11-18T11:30:19
* **Crop size:** 224x224 px (MediaPipe hand box + 30% margin)
* **Camera view:** mirrored (selfie view), same as the training notebook

## Angles recorded for every letter
1. `front` - Straight at the camera
2. `side` - Turn hand a little to the SIDE

## Folders
* `crops/<LETTER>/` - 224x224 training crops
* (full camera frames were not saved)
* `metadata.csv` - one row per image: letter, session, angle, handedness, bounding box, 21 raw landmarks (x, y, z)
* `presentation/` - charts and posters

## Collection method
A frame was saved only if MediaPipe detected the whole hand with enough confidence, the crop was sharp, and the hand pose differed from the last 8 saved frames - so the images are varied, not near-duplicates.

## Images per letter

| A | B | C | D | E | F | G | H | I | J | K | L | M | N | O | P | Q | R | S | T | U | V | W | X | Y | Z |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 | 50 |
